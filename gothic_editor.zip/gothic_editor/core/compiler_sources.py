"""Compiler-specific whitespace preparation, confined to the staging tree."""
from .daedalus_merge import normalize_compiler_whitespace
from .localization import tr
from .scripts import load_text


def prepare_compiler_sources(content, report):
    for path in sorted(content.rglob('*')):
        if not path.is_file() or path.suffix.casefold() != '.d':
            continue
        raw = path.read_bytes()
        if b'\x0c' not in raw:
            continue
        text, codec = load_text(path)
        normalized, count = normalize_compiler_whitespace(text)
        if not count:
            continue
        if codec == 'utf-8-sig' and not raw.startswith(b'\xef\xbb\xbf'):
            codec = 'utf-8'
        path.write_bytes(normalized.encode(codec))
        report(tr('tools.normalized_whitespace', path=str(path.relative_to(content)), count=count))
