from gothic_editor.app import main
if __name__ == '__main__':
    main()
